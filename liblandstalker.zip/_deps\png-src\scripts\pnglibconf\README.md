pnglibconf - libpng configuration utilities
===========================================

Copyright Notice
----------------

 * Copyright (c) 2025 Cosmin Truta.
 * Copyright (c) 2010-2014 Glenn Randers-Pehrson.
 * Originally written by John Bowler, 2010.

Use, modification and distribution of the pnglibconf
software in the libpng distribution are subject to
the same licensing terms and conditions as libpng.
Please see the copyright notice in `png.h` or visit
http://libpng.org/pub/png/src/libpng-LICENSE.txt
