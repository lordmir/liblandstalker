Autoconf Macro Files for the PNG Reference Library
==================================================

This directory is reserved for Autoconf-generated M4 macro files.

Use, modification and distribution of each individual file are subject to
the specific licensing terms and conditions stated at the top of the file.
