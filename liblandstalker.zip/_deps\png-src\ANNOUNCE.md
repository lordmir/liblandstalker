libpng 1.8.0.git
================

This is a development version, not intended to be a public release.
It will be replaced by a public release, or by another development
version, at a later time.

*****

Send comments/corrections/commendations to png-mng-implement at lists.sf.net.
Subscription is required; visit
https://lists.sourceforge.net/lists/listinfo/png-mng-implement
to subscribe.
