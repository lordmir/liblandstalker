PNG REFERENCE LIBRARY AUTHORS
=============================

This is the list of PNG Reference Library ("libpng") Contributing
Authors, for copyright and licensing purposes.

 * Adam Richter
 * Andreas Dilger
 * Chris Blume
 * Cosmin Truta
 * Daisuke Nishikawa
 * Dave Martindale
 * Eric S. Raymond
 * Gilles Vollant
 * Glenn Randers-Pehrson
 * Greg Roelofs
 * Guy Eric Schalnat
 * James Yu
 * John Bowler
 * Kevin Bracey
 * Lucas Chollet
 * Maarten Bent
 * Magnus Holmgren
 * Mandar Sahastrabuddhe
 * Manfred Schlaegl
 * Mans Rullgard
 * Matt Sarett
 * Mike Klein
 * Pascal Massimino
 * Paul Schmidt
 * Philippe Antoine
 * Qiang Zhou
 * Sam Bushell
 * Samuel Williams
 * Simon-Pierre Cadieux
 * Tim Wegner
 * Tobias Stoeckmann
 * Tom Lane
 * Tom Tanner
 * Vadim Barkov
 * Willem van Schaik
 * Zhijie Liang
 * Apple Inc.
    - Zixu Wang (王子旭)
 * Arm Holdings
    - Richard Townsend
 * Google LLC
    - Dan Field
    - Dragoș Tiselice
    - Leon Scroggins III
    - Matt Sarett
    - Mike Klein
    - Sami Boukortt
    - Wan-Teh Chang
 * Loongson Technology Corporation Ltd.
    - GuXiWei (顾希伟)
    - JinBo (金波)
    - ZhangLixia (张利霞)
 * Samsung Group
    - Filip Wasil

The build projects, the build scripts, the test scripts, and other
files in the "projects", "scripts" and "tests" directories, have
other copyright owners, but are released under the libpng license.

Some files in the "ci" and "contrib" directories, as well as some
of the tools-generated files that are distributed with libpng, have
other copyright owners, and are released under other open source
licenses.
