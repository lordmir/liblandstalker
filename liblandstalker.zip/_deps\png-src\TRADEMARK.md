TRADEMARK
=========

The name "libpng" has not been registered by the Copyright owners
as a trademark in any jurisdiction.  However, because libpng has
been distributed and maintained world-wide, continually since 1995,
the Copyright owners claim "common-law trademark protection" in any
jurisdiction where common-law trademark is recognized.
